package com.example.weigharc;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WeightHistoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TableLayout tableWeightHistory;

    private EditText editDate;
    private EditText editWeight;
    private EditText editGoalWeight;

    private Button buttonAddWeight;

    private boolean formattingDate = false;

    private int selectedWeightId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight_history);

        databaseHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        tableWeightHistory =
                findViewById(R.id.tableWeightHistory);

        editDate =
                findViewById(R.id.editDate);

        editWeight =
                findViewById(R.id.editWeight);

        editGoalWeight =
                findViewById(R.id.editGoalWeight);

        buttonAddWeight =
                findViewById(R.id.buttonAddWeight);

        Button buttonSetGoal =
                findViewById(R.id.buttonSetGoal);

        Button buttonSmsNotifications =
                findViewById(R.id.buttonSmsNotifications);

        Button buttonLogout =
                findViewById(R.id.buttonLogout);

        // Load the saved goal if there is one
        double savedGoal = databaseHelper.getGoal();

        if (savedGoal != -1) {
            editGoalWeight.setText(
                    String.valueOf(savedGoal)
            );
        }

        // Add the slashes while the date is being typed
        editDate.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {
                    }

                    @Override
                    public void afterTextChanged(
                            Editable editable) {

                        if (formattingDate) {
                            return;
                        }

                        String numbersOnly =
                                editable.toString()
                                        .replace("/", "");

                        if (numbersOnly.length() > 8) {
                            numbersOnly =
                                    numbersOnly.substring(0, 8);
                        }

                        StringBuilder formattedDate =
                                new StringBuilder();

                        for (int i = 0;
                             i < numbersOnly.length();
                             i++) {

                            if (i == 2 || i == 4) {
                                formattedDate.append("/");
                            }

                            formattedDate.append(
                                    numbersOnly.charAt(i)
                            );
                        }

                        formattingDate = true;

                        editDate.setText(
                                formattedDate.toString()
                        );

                        editDate.setSelection(
                                formattedDate.length()
                        );

                        formattingDate = false;
                    }
                }
        );

        // Show the weights saved in the database
        loadWeights();

        // Add a new weight or update the one being edited
        buttonAddWeight.setOnClickListener(v -> {

            String date =
                    editDate.getText()
                            .toString()
                            .trim();

            String weightText =
                    editWeight.getText()
                            .toString()
                            .trim();

            if (date.isEmpty()
                    || weightText.isEmpty()) {

                Toast.makeText(
                        this,
                        "Enter a date and weight",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            double weight;

            try {
                weight =
                        Double.parseDouble(weightText);

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Enter a valid weight",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (selectedWeightId != -1) {

                // Update the selected weight
                boolean weightUpdated =
                        databaseHelper.updateWeight(
                                selectedWeightId,
                                date,
                                weight
                        );

                if (weightUpdated) {

                    Toast.makeText(
                            this,
                            "Weight updated",
                            Toast.LENGTH_SHORT
                    ).show();

                    checkGoalAndSendSms(weight);

                    selectedWeightId = -1;

                    buttonAddWeight.setText(
                            R.string.add_weight
                    );

                    editDate.setText("");
                    editWeight.setText("");

                    loadWeights();

                } else {

                    Toast.makeText(
                            this,
                            "Weight could not be updated",
                            Toast.LENGTH_SHORT
                    ).show();
                }

            } else {

                // Add a new weight to the database
                boolean weightAdded =
                        databaseHelper.addWeight(
                                date,
                                weight
                        );

                if (weightAdded) {

                    Toast.makeText(
                            this,
                            "Weight added",
                            Toast.LENGTH_SHORT
                    ).show();

                    checkGoalAndSendSms(weight);

                    editDate.setText("");
                    editWeight.setText("");

                    loadWeights();

                } else {

                    Toast.makeText(
                            this,
                            "Weight could not be added",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });

        // Save the goal weight
        buttonSetGoal.setOnClickListener(v -> {

            String goalText =
                    editGoalWeight.getText()
                            .toString()
                            .trim();

            if (goalText.isEmpty()) {

                Toast.makeText(
                        this,
                        "Enter a goal weight",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            double goalWeight;

            try {
                goalWeight =
                        Double.parseDouble(goalText);

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Enter a valid goal weight",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean goalSaved =
                    databaseHelper.saveGoal(
                            goalWeight
                    );

            if (goalSaved) {

                Toast.makeText(
                        this,
                        "Goal weight saved",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Goal weight could not be saved",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Open the SMS settings screen
        buttonSmsNotifications.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            WeightHistoryActivity.this,
                            SMSNotificationsActivity.class
                    );

            startActivity(intent);
        });

        // Log out and go back to the login screen
        buttonLogout.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            WeightHistoryActivity.this,
                            MainActivity.class
                    );

            startActivity(intent);
            finish();
        });
    }

    // Check the goal before trying to send a text
    private void checkGoalAndSendSms(double weight) {

        double goalWeight =
                databaseHelper.getGoal();

        // Stop if a goal has not been saved
        if (goalWeight == -1) {
            return;
        }

        // Stop if the goal has not been reached
        if (weight > goalWeight) {
            return;
        }

        // Stop if SMS notifications are turned off
        if (!databaseHelper.isSmsEnabled()) {
            return;
        }

        String phoneNumber =
                databaseHelper.getPhoneNumber();

        // Stop if there is no phone number
        if (phoneNumber.isEmpty()) {
            return;
        }

        // Stop if SMS permission was not granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        try {

            SmsManager smsManager =
                    getSystemService(
                            SmsManager.class
                    );

            if (smsManager != null) {

                String message =
                        getString(
                                R.string.goal_sms_message,
                                goalWeight
                        );

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        "Goal reached. SMS alert sent.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS alert could not be sent",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Reload the weight history table
    private void loadWeights() {

        // Keep the header and remove the old rows
        if (tableWeightHistory.getChildCount() > 1) {

            tableWeightHistory.removeViews(
                    1,
                    tableWeightHistory.getChildCount() - 1
            );
        }

        Cursor cursor =
                databaseHelper.getAllWeights();

        Double previousWeight = null;

        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "id"
                            )
                    );

            String date =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "date"
                            )
                    );

            double weight =
                    cursor.getDouble(
                            cursor.getColumnIndexOrThrow(
                                    "weight"
                            )
                    );

            TableRow row =
                    new TableRow(this);

            TextView dateText =
                    new TextView(this);

            dateText.setText(date);
            dateText.setGravity(Gravity.CENTER);
            dateText.setPadding(
                    8,
                    8,
                    8,
                    8
            );

            TextView weightText =
                    new TextView(this);

            weightText.setText(
                    getString(
                            R.string.weight_display,
                            weight
                    )
            );

            weightText.setGravity(
                    Gravity.CENTER
            );

            weightText.setPadding(
                    8,
                    8,
                    8,
                    8
            );

            // Change the color based on the previous weight
            if (previousWeight == null) {

                weightText.setTextColor(
                        ContextCompat.getColor(
                                this,
                                R.color.no_change_black
                        )
                );

            } else if (weight < previousWeight) {

                weightText.setTextColor(
                        ContextCompat.getColor(
                                this,
                                R.color.loss_green
                        )
                );

            } else if (weight > previousWeight) {

                weightText.setTextColor(
                        ContextCompat.getColor(
                                this,
                                R.color.gain_red
                        )
                );

            } else {

                weightText.setTextColor(
                        ContextCompat.getColor(
                                this,
                                R.color.no_change_black
                        )
                );
            }

            previousWeight = weight;

            Button editButton =
                    new Button(this);

            editButton.setText(
                    R.string.edit
            );

            Button deleteButton =
                    new Button(this);

            deleteButton.setText(
                    R.string.delete
            );

            // Keep the buttons large enough to tap
            editButton.setTextSize(12);
            deleteButton.setTextSize(12);

            editButton.setMinHeight(
                    dpToPx(48)
            );

            deleteButton.setMinHeight(
                    dpToPx(48)
            );

            editButton.setMinWidth(
                    dpToPx(72)
            );

            deleteButton.setMinWidth(
                    dpToPx(72)
            );

            // Put this weight into the fields so it can be edited
            editButton.setOnClickListener(v -> {

                selectedWeightId = id;

                editDate.setText(date);

                editWeight.setText(
                        String.valueOf(weight)
                );

                buttonAddWeight.setText(
                        R.string.update_weight
                );
            });

            // Delete this weight from the database
            deleteButton.setOnClickListener(v -> {

                boolean weightDeleted =
                        databaseHelper.deleteWeight(id);

                if (weightDeleted) {

                    Toast.makeText(
                            this,
                            "Weight deleted",
                            Toast.LENGTH_SHORT
                    ).show();

                    if (selectedWeightId == id) {

                        selectedWeightId = -1;

                        editDate.setText("");
                        editWeight.setText("");

                        buttonAddWeight.setText(
                                R.string.add_weight
                        );
                    }

                    loadWeights();

                } else {

                    Toast.makeText(
                            this,
                            "Weight could not be deleted",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });

            // Put Edit and Delete together in the Action column
            LinearLayout actionLayout =
                    new LinearLayout(this);

            actionLayout.setOrientation(
                    LinearLayout.VERTICAL
            );

            actionLayout.setGravity(
                    Gravity.CENTER
            );

            actionLayout.addView(
                    editButton
            );

            actionLayout.addView(
                    deleteButton
            );

            row.addView(dateText);
            row.addView(weightText);
            row.addView(actionLayout);

            // Put the newest weight at the top
            tableWeightHistory.addView(
                    row,
                    1
            );
        }

        cursor.close();
    }

    // Convert dp to pixels for the button sizes
    private int dpToPx(int dp) {

        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                dp * density
        );
    }
}