package com.example.weigharc;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SMSNotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private DatabaseHelper databaseHelper;
    private EditText editPhoneNumber;
    private TextView textSmsStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notifications);

        databaseHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textSmsStatus = findViewById(R.id.textSmsStatus);

        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonNotNow = findViewById(R.id.buttonNotNow);
        Button buttonBackToHistory = findViewById(R.id.buttonBackToHistory);

        // Show the saved phone number
        String savedPhoneNumber = databaseHelper.getPhoneNumber();

        if (!savedPhoneNumber.isEmpty()) {
            editPhoneNumber.setText(savedPhoneNumber);
        }

        // Show the current SMS notification status
        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted && databaseHelper.isSmsEnabled()) {
            textSmsStatus.setText(R.string.sms_status_granted);
        } else if (permissionGranted) {
            textSmsStatus.setText(R.string.sms_status_off);
        } else {
            textSmsStatus.setText(R.string.sms_status_not_granted);
        }

        // Enable SMS notifications
        buttonEnableSms.setOnClickListener(v -> {
            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(this,
                        "Enter a phone number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                boolean saved =
                        databaseHelper.saveSmsSettings(phoneNumber, true);

                if (saved) {
                    textSmsStatus.setText(R.string.sms_status_granted);

                    Toast.makeText(this,
                            "SMS notifications enabled",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            }
        });

        // Turn off SMS notifications
        buttonNotNow.setOnClickListener(v -> {
            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            databaseHelper.saveSmsSettings(phoneNumber, false);
            textSmsStatus.setText(R.string.sms_status_off);

            Toast.makeText(this,
                    "SMS notifications turned off",
                    Toast.LENGTH_SHORT).show();
        });

        // Return to the Weight History screen
        buttonBackToHistory.setOnClickListener(v -> finish());
    }

    // Update the SMS setting after the user responds
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                databaseHelper.saveSmsSettings(
                        phoneNumber,
                        true
                );

                textSmsStatus.setText(
                        R.string.sms_status_granted
                );

                Toast.makeText(
                        this,
                        "SMS notifications enabled",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                databaseHelper.saveSmsSettings(
                        phoneNumber,
                        false
                );

                textSmsStatus.setText(
                        R.string.sms_status_not_granted
                );
            }
        }
    }
}