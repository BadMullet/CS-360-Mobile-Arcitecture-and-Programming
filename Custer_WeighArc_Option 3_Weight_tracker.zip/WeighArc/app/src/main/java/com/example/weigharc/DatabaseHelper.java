package com.example.weigharc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weigharc.db";
    private static final int DATABASE_VERSION = 3;

    public static final String USER_TABLE = "users";
    public static final String WEIGHT_TABLE = "weights";
    public static final String GOAL_TABLE = "goals";
    public static final String SMS_TABLE = "sms_settings";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store usernames and passwords
        String createUserTable = "CREATE TABLE " + USER_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)";

        // Store weight history
        String createWeightTable = "CREATE TABLE " + WEIGHT_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT NOT NULL, " +
                "weight REAL NOT NULL)";

        // Store the user's goal weight
        String createGoalTable = "CREATE TABLE " + GOAL_TABLE + " (" +
                "id INTEGER PRIMARY KEY, " +
                "goal_weight REAL NOT NULL)";

        // Store SMS settings
        String createSmsTable = "CREATE TABLE " + SMS_TABLE + " (" +
                "id INTEGER PRIMARY KEY, " +
                "phone_number TEXT, " +
                "sms_enabled INTEGER NOT NULL DEFAULT 0)";

        db.execSQL(createUserTable);
        db.execSQL(createWeightTable);
        db.execSQL(createGoalTable);
        db.execSQL(createSmsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2) {
            String createGoalTable = "CREATE TABLE " + GOAL_TABLE + " (" +
                    "id INTEGER PRIMARY KEY, " +
                    "goal_weight REAL NOT NULL)";

            db.execSQL(createGoalTable);
        }

        if (oldVersion < 3) {
            String createSmsTable = "CREATE TABLE " + SMS_TABLE + " (" +
                    "id INTEGER PRIMARY KEY, " +
                    "phone_number TEXT, " +
                    "sms_enabled INTEGER NOT NULL DEFAULT 0)";

            db.execSQL(createSmsTable);
        }
    }

    // Add a new user to the database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(USER_TABLE, null, values);

        return result != -1;
    }

    // Check the username and password during login
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USER_TABLE +
                        " WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        boolean userExists = cursor.getCount() > 0;
        cursor.close();

        return userExists;
    }

    // Add a new weight entry to the database
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);

        long result = db.insert(WEIGHT_TABLE, null, values);

        return result != -1;
    }

    // Get all saved weight entries
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + WEIGHT_TABLE + " ORDER BY id ASC",
                null
        );
    }

    // Delete a weight entry from the database
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                WEIGHT_TABLE,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }

    // Update an existing weight entry
    public boolean updateWeight(int id, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);

        int rowsUpdated = db.update(
                WEIGHT_TABLE,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsUpdated > 0;
    }

    // Save or replace the goal weight
    public boolean saveGoal(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("id", 1);
        values.put("goal_weight", goalWeight);

        long result = db.insertWithOnConflict(
                GOAL_TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        );

        return result != -1;
    }

    // Get the saved goal weight
    public double getGoal() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT goal_weight FROM " + GOAL_TABLE + " WHERE id = 1",
                null
        );

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("goal_weight")
            );
        }

        cursor.close();

        return goalWeight;
    }

    // Save the phone number and SMS setting
    public boolean saveSmsSettings(String phoneNumber, boolean enabled) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("id", 1);
        values.put("phone_number", phoneNumber);
        values.put("sms_enabled", enabled ? 1 : 0);

        long result = db.insertWithOnConflict(
                SMS_TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        );

        return result != -1;
    }

    // Get the saved phone number
    public String getPhoneNumber() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT phone_number FROM " + SMS_TABLE + " WHERE id = 1",
                null
        );

        String phoneNumber = "";

        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone_number")
            );
        }

        cursor.close();

        return phoneNumber;
    }

    // Check whether SMS notifications are turned on
    public boolean isSmsEnabled() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT sms_enabled FROM " + SMS_TABLE + " WHERE id = 1",
                null
        );

        boolean enabled = false;

        if (cursor.moveToFirst()) {
            enabled = cursor.getInt(
                    cursor.getColumnIndexOrThrow("sms_enabled")
            ) == 1;
        }

        cursor.close();

        return enabled;
    }
}