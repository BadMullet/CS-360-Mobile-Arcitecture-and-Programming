package com.example.weigharc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Check the username and password before logging in
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean loginSuccessful =
                    databaseHelper.checkUser(username, password);

            if (loginSuccessful) {
                Intent intent = new Intent(MainActivity.this,
                        WeightHistoryActivity.class);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(this,
                        "Incorrect username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Create a new user account
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean accountCreated =
                    databaseHelper.addUser(username, password);

            if (accountCreated) {
                Toast.makeText(this,
                        "Account created",
                        Toast.LENGTH_SHORT).show();

                editUsername.setText("");
                editPassword.setText("");
            } else {
                Toast.makeText(this,
                        "Account could not be created",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}