package com.example.weigharc;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SMSNotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notifications);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonNotNow = findViewById(R.id.buttonNotNow);
        TextView textSmsStatus = findViewById(R.id.textSmsStatus);

        // Return to the Weight History screen
        Button buttonBackToHistory = findViewById(R.id.buttonBackToHistory);
        buttonBackToHistory.setOnClickListener(v -> finish());

        // Check the current SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textSmsStatus.setText(R.string.sms_status_granted);
        } else {
            textSmsStatus.setText(R.string.sms_status_not_granted);
        }

        buttonEnableSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                textSmsStatus.setText(R.string.sms_status_granted);

            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            }
        });

        buttonNotNow.setOnClickListener(v -> {
            textSmsStatus.setText(R.string.sms_status_off);
        });
    }

    // Update the status after the user responds
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        TextView textSmsStatus = findViewById(R.id.textSmsStatus);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                textSmsStatus.setText(R.string.sms_status_granted);

            } else {
                textSmsStatus.setText(R.string.sms_status_not_granted);
            }
        }
    }
}
